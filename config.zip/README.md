# Backend File Structure

This document outlines the organized backend structure for the Melzo website admin panel.

## Directory Structure

```
backend/
├── config/
│   └── db.js                 # Database configuration
├── controllers/              # Request handlers
│   ├── blogController.js
│   ├── caseStudyController.js
│   ├── footerController.js
│   ├── messageController.js
│   └── newsController.js
├── routes/                   # API route definitions
│   ├── blogRoutes.js
│   ├── caseStudyRoutes.js
│   ├── footerRoutes.js
│   ├── messageRoutes.js
│   └── newsRoutes.js
├── services/                 # Business logic layer
│   ├── blogService.js
│   ├── caseStudyService.js
│   └── newsService.js
├── .env                      # Environment variables
├── .gitignore
├── package.json
└── server.js                 # Express server entry point
```

## Architecture Pattern

The backend follows a **3-tier architecture**:

### 1. Routes Layer (`routes/`)
- Defines API endpoints
- Maps HTTP methods to controller functions
- Example: `GET /api/blogs` → `blogController.getBlogs`

### 2. Controllers Layer (`controllers/`)
- Handles HTTP requests and responses
- Validates request data
- Calls service layer for business logic
- Formats responses

### 3. Services Layer (`services/`)
- Contains business logic
- Interacts with the database
- Reusable across different controllers
- Handles data transformation

## API Endpoints

### Demo/Messages
- `GET /api/messages` - Get all demo requests
- `POST /api/messages` - Create new demo request

### Blogs
- `GET /api/blogs` - Get all blogs
- `GET /api/blogs/:id` - Get single blog (by ID or slug)
- `POST /api/blogs` - Create new blog
- `PUT /api/blogs/:id` - Update blog
- `DELETE /api/blogs/:id` - Delete blog
- `PATCH /api/blogs/:id/visibility` - Toggle blog visibility

### News
- `GET /api/news` - Get all news
- `GET /api/news/:id` - Get single news item
- `POST /api/news` - Create new news
- `PUT /api/news/:id` - Update news
- `DELETE /api/news/:id` - Delete news
- `PATCH /api/news/:id/visibility` - Toggle news visibility

### Case Studies
- `GET /api/case-studies` - Get all case studies
- `GET /api/case-studies/:id` - Get single case study (by ID or slug)
- `POST /api/case-studies` - Create new case study
- `PUT /api/case-studies/:id` - Update case study
- `DELETE /api/case-studies/:id` - Delete case study
- `PATCH /api/case-studies/:id/visibility` - Toggle case study visibility

### Footer
- `GET /api/footer` - Get footer configuration
- `POST /api/footer` - Save footer configuration

## Frontend Service Files

Corresponding frontend services are located in `website/src/services/`:

```
website/src/services/
├── api.js                    # Axios instance with auth interceptor
├── blogService.js            # Blog API calls
├── caseStudyService.js       # Case study API calls
├── newsService.js            # News API calls
└── mockStorage.js            # Legacy localStorage (being phased out)
```

## Database Schema Requirements

### blogs
```sql
CREATE TABLE blogs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    author JSON,
    publishDate VARCHAR(50),
    readTime INT,
    category VARCHAR(100),
    excerpt TEXT,
    status VARCHAR(50) DEFAULT 'Draft',
    isVisible BOOLEAN DEFAULT TRUE,
    image VARCHAR(255),
    content JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### news
```sql
CREATE TABLE news (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(100),
    date VARCHAR(50),
    title VARCHAR(255) NOT NULL,
    excerpt TEXT,
    image VARCHAR(255),
    language VARCHAR(50) DEFAULT 'English',
    content TEXT,
    isVisible BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### case_studies
```sql
CREATE TABLE case_studies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT,
    image VARCHAR(255),
    type VARCHAR(50) DEFAULT 'image',
    mediaUrl VARCHAR(255),
    isVisible BOOLEAN DEFAULT TRUE,
    content JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### messages (Demo Requests)
```sql
CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    institute VARCHAR(255),
    designation VARCHAR(100),
    demo_date DATE,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Next Steps

To complete the backend integration:

1. **Create database tables** using the SQL schemas above
2. **Add remaining services** for:
   - Testimonials
   - Awards
   - FAQs
   - Team
   - Timeline
   - Industries
   - Jobs
   - Job Applications

3. **Update frontend** to use new service files instead of mockStorage
4. **Add authentication middleware** for protected routes
5. **Implement file upload** for images
6. **Add validation middleware** for request data

## Running the Backend

```bash
cd backend
npm install
npm run dev
```

The server will start on `http://localhost:3000`

## Environment Variables

Create a `.env` file in the backend directory:

```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=melzo_db
```
#   w e b s i t e _ b a c k e n d  
 